import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function LoginRegister() {
    const navigate = useNavigate();
    const [registerState, setRegisterState] = useState({
        userName: '',
        email: '',
        password: '',
        confirmPassword: ''
    });
    const [loginState, setLoginState] = useState({
        email: '',
        password: ''
    });


    const [registerMessage, setRegisterMessage] = useState('');
    const [loginMessage, setLoginMessage] = useState('');


    const register = (event) => {
        event.preventDefault();

        if (registerState.password !== registerState.confirmPassword) {
            setRegisterMessage('Passwords do not match');
            return;
        }
        if (registerState.userName === ''  || registerState.email === '') {
            setRegisterMessage('Please fill out all required fields');
            return;
        }
        if (registerState.password.length < 8) {
            setRegisterMessage('Password should be at least 8 characters long');
            return;
        }

        console.log("Attempting to register with data: ", registerState);

        axios.post('http://localhost:8000/api/register', registerState)
            .then(response => {
                console.log("Response from server: ", response);
                setRegisterMessage('User registered successfully!');

                localStorage.setItem('user', JSON.stringify(response.data.user));
                localStorage.setItem('token', response.data.token);

                setTimeout(() => {
                    navigate('/dashboard');
                }, 5000);
            })
            .catch(err => {
                console.error(err);
                if (err.response) {
                    console.log("Error from server: ", err.response.data);
                    setRegisterMessage(err.response.data.message);
                } else if (err.request) {
                    console.log("Error in request: ", err.request);
                } else {
                    console.log('Other error', err.message);
                }
            });
    }


    const login = (event) => {
        event.preventDefault();
        console.log(loginState);
        axios.post('http://localhost:8000/api/login', loginState)
            .then(response => {
                console.log(response.data);

                localStorage.setItem('user', JSON.stringify(response.data.user));
                localStorage.setItem('token', response.data.token);

                setLoginMessage(response.data.msg);


                setTimeout(() => {
                    navigate('/dashboard');
                }, 5000);

            })
            .catch(err => {
                console.error(err);
                if (err.response && err.response.data) {
                    setLoginMessage(err.response.data.msg);
                }
            });
    }

    return (
        <div className="form-container">
            <div className="form-section">
                <h2>Register</h2>
                <form onSubmit={register}>
                    <input
                        type="text"
                        value={registerState.userName}
                        onChange={(e) =>
                            setRegisterState({ ...registerState, userName: e.target.value })
                        }
                        placeholder=" userName"
                    /> <br />
                    <input
                        type="email"
                        value={registerState.email}
                        onChange={(e) =>
                            setRegisterState({ ...registerState, email: e.target.value })
                        }
                        placeholder="Email"
                    /> <br />
                    <input
                        type="password"
                        value={registerState.password}
                        onChange={(e) =>
                            setRegisterState({ ...registerState, password: e.target.value })
                        }
                        placeholder="Password"
                    /> <br />
                    <input
                        type="password"
                        value={registerState.confirmPassword}
                        onChange={(e) =>
                            setRegisterState({
                                ...registerState,
                                confirmPassword: e.target.value
                            })
                        }
                        placeholder="Confirm Password"
                    /> <br />
                    <button type="submit">Register</button>
                </form>
                <div>
                    <p>{registerMessage}</p>
                </div>
            </div>
            <div className="form-section">
                <h2>Login</h2>
                <form onSubmit={login}>
                    <input
                        type="email"
                        value={loginState.email}
                        onChange={(e) =>
                            setLoginState({ ...loginState, email: e.target.value })
                        }
                        placeholder="Email"
                    />
                    <input
                        type="password"
                        value={loginState.password}
                        onChange={(e) =>
                            setLoginState({ ...loginState, password: e.target.value })
                        }
                        placeholder="Password"
                    />
                    <button type="submit">Login</button>
                </form>
                <div>
                    <p>{loginMessage}</p>
                </div>
            </div>
        </div>
    );
}

export default LoginRegister;