// import logo from './logo.svg';
// import './App.css';
import {Routes,Route} from 'react-router-dom'
import LoginRegister from './components/LoginRegister';
import Dashboard from './components/Dashboard';

function App() {
    const baseUrl = "http://localhost:8080/api"
    return (
      <>
        <Routes>
        <Route path='/' element={<LoginRegister baseUrl={baseUrl}/>}/>
        <Route path='/dashboard' element={<Dashboard baseUrl={baseUrl}/>}/>
        {/* <Route path='/pirates/new' element={<LoginRegister baseUrl={baseUrl}/>}/>
       
        <Route path='/pirates/:id' element={<ShowOne baseUrl={baseUrl}/>}/> */}
        </Routes>
      </>
  );
}

export default App;
