const express = require('express');
const app = express();
require('dotenv').config();
const cors = require('cors');
const mongooseConfig = require('./config/mongoose.config');

const DB = process.env.DB;
const PORT = process.env.PORT || 8000;

app.use(cors());
app.use(express.json());

mongooseConfig(DB);

require('./routes/user.routes')(app);
require('./routes/menu.routes')(app)
// require('./routes/order.routes')(app);
// require('./routes/cart.routes')(app);

app.listen(PORT, () => console.log(`Engine's ready on port ${PORT}`));
