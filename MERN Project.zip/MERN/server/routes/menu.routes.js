const MenuController = require('../controllers/menu.controller');


module.exports = app => {
   
    app.post('/api/menu/create', MenuController.createMenuItem)
    app.get('/api/menu/all', MenuController.getAllMenuItems)
    app.put('/api/menu/:id', MenuController.updateMenuItem)
    app.delete('/api/menu/destroy/:id', MenuController.deleteMenuItem)

};