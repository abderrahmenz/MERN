const Order = require('../models/order.model');
const Cart = require('../models/cart.model');

// Créer une nouvelle commande
exports.createOrder = async (req, res) => {
    try {
        const { userId } = req.body;
        const cart = await Cart.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ message: 'Panier non trouvé' });
        }

        const newOrder = new Order({
            userId: cart.userId,
            items: cart.items,
            total: cart.total,
            status: 'pending'
        });

        await newOrder.save();

        // Vider le panier après avoir passé la commande
        await Cart.findOneAndUpdate(
            { userId },
            { $set: { items: [], total: 0 } },
            { new: true }
        );

        res.status(201).json(newOrder);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la création de la commande', error });
    }
};

// Obtenir toutes les commandes
exports.getAllOrders = async (req, res) => {
    try {
        const orders = await Order.find({}).populate('items.itemId');
        res.status(200).json(orders);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la récupération des commandes', error });
    }
};

// Obtenir une commande par ID
exports.getOrderById = async (req, res) => {
    try {
        const order = await Order.findById(req.params.id).populate('items.itemId');
        if (!order) {
            return res.status(404).json({ message: 'Commande non trouvée' });
        }
        res.status(200).json(order);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la récupération de la commande', error });
    }
};

// Mettre à jour le statut d'une commande
exports.updateOrderStatus = async (req, res) => {
    try {
        const { orderId, status } = req.params;
        const order = await Order.findByIdAndUpdate(orderId, { status }, { new: true });
        if (!order) {
            return res.status(404).json({ message: 'Commande non trouvée' });
        }
        res.status(200).json(order);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la mise à jour de la commande', error });
    }
};

// Supprimer une commande
exports.deleteOrder = async (req, res) => {
    try {
        const { orderId } = req.params;
        const order = await Order.findByIdAndDelete(orderId);
        if (!order) {
            return res.status(404).json({ message: 'Commande non trouvée' });
        }
        res.status(200).json({ message: 'Commande supprimée avec succès' });
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la suppression de la commande', error });
    }
};
