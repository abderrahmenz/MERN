const Menu = require('../models/menu.model');

// Créer un nouvel élément de menu
exports.createMenuItem = async (req, res) => {
    try {
        const newMenuItem = {
            name: req.body.name,
            description: req.body.description,
            image: req.body.image,
            price: req.body.price,
        };
        const menu = await Menu.findOneAndUpdate(
            {},
            { $push: { items: newMenuItem } },
            { new: true, upsert: true }
        );
        res.status(201).json(menu);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la création de l\'élément de menu', error });
    }
};

// Obtenir tous les éléments de menu
exports.getAllMenuItems = async (req, res) => {
    try {
        const menu = await Menu.findOne({});
        res.status(200).json(menu.items);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la récupération des éléments de menu', error });
    }
};

// Mettre à jour un élément de menu
exports.updateMenuItem = async (req, res) => {
    try {
        const { id } = req.params; // Utilisation de `id` au lieu de `itemId`
        const updatedMenuItem = await Menu.findOneAndUpdate(
            { "items._id": id },
            {
                $set: {
                    "items.$.name": req.body.name,
                    "items.$.description": req.body.description,
                    "items.$.image": req.body.image,
                    "items.$.price": req.body.price
                }
            },
            { new: true }
        );
        res.status(200).json(updatedMenuItem);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la mise à jour de l\'élément de menu', error });
    }
};
// Supprimer un élément de menu
exports.deleteMenuItem = async (req, res) => {
    try {
        const { id } = req.params; // Utilisation de `id` au lieu de `itemId`
        const menu = await Menu.findOneAndUpdate(
            {},
            { $pull: { items: { _id: id } } },
            { new: true }
        );
        res.status(200).json(menu);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la suppression de l\'élément de menu', error });
    }
};