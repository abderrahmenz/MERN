const User = require('../models/user.model.js');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const jwtSecret = process.env.JWT_SECRET;

console.log('JWT Secret:', jwtSecret);  // Ligne de débogage

exports.register = async (req, res) => {
    // Existing code...
};

exports.login = async (req, res) => {
    // Existing code...
};

exports.logout = (req, res) => {
    // Existing code...
};

exports.getAllUsers = async (req, res) => {
    // Existing code...
};

exports.createUser = async (req, res) => {
    const { userName } = req.body;
    if (!userName) {
        return res.status(400).json({ message: 'Name is required' });
    }

    try {
        const newUser = new User({ userName });
        await newUser.save();
        res.status(201).json(newUser);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
