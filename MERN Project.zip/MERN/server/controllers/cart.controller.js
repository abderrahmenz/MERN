const Cart = require('../models/cart.model');
const Menu = require('../models/menu.model');

// Ajouter un article au panier
exports.addToCart = async (req, res) => {
    try {
        const { userId, itemId, quantity } = req.body;
        const menuItem = await Menu.findOne({ "items._id": itemId });
        if (!menuItem) {
            return res.status(404).json({ message: 'Article de menu non trouvé' });
        }
        const item = menuItem.items.id(itemId);

        const cart = await Cart.findOneAndUpdate(
            { userId },
            {
                $push: { items: { itemId, name: item.name, price: item.price, quantity } },
                $inc: { total: item.price * quantity }
            },
            { new: true, upsert: true }
        );
        res.status(200).json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de l\'ajout de l\'article au panier', error });
    }
};

// Obtenir le panier d'un utilisateur
exports.getCartByUserId = async (req, res) => {
    try {
        const { userId } = req.params;
        const cart = await Cart.findOne({ userId }).populate('items.itemId');
        res.status(200).json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la récupération du panier', error });
    }
};

// Mettre à jour un article du panier
exports.updateCartItem = async (req, res) => {
    try {
        const { userId, itemId } = req.params;
        const { quantity } = req.body;
        const cart = await Cart.findOneAndUpdate(
            { userId, "items.itemId": itemId },
            {
                $set: { "items.$.quantity": quantity },
                $inc: { total: (req.body.price * quantity) }
            },
            { new: true }
        );
        res.status(200).json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la mise à jour de l\'article du panier', error });
    }
};

// Supprimer un article du panier
exports.removeFromCart = async (req, res) => {
    try {
        const { userId, itemId } = req.params;
        const cart = await Cart.findOneAndUpdate(
            { userId },
            { $pull: { items: { itemId } } },
            { new: true }
        );
        res.status(200).json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Erreur lors de la suppression de l\'article du panier', error });
    }
};
