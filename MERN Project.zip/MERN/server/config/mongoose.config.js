const mongoose = require('mongoose');

module.exports = (DB) => {
    mongoose.connect(`mongodb+srv://abderrahmenzarrougui7:admin1234@cluster0.mfokkzm.mongodb.net/${DB}?retryWrites=true&w=majority`, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(() => console.log('Established a connection to the database ✅✅✅✅✅'))
    .catch(err => console.log('Something went wrong when connecting to the database ❌❌❌❌❌', err));
};
